# ATS Audio Player (ATS-2835P DSP) - Android Studio Project

## Características
- **AndroidX Media3 1.2.1** (ExoPlayer + MediaSessionService + MediaController)
- **DSP DynamicsProcessing**:
  - **PreEQ de 32 Bandas** (20Hz a 20kHz, -12dB a +12dB con centro en 0dB).
  - **MDRC de 5 Bandas** (Multi-band Dynamic Range Control con cutoffs, threshold, ratio, attack, release, knee y vúmetro de reducción).
  - **PostEQ de 5 Bandas**.
  - **Peak Limiter** (-1dB threshold, ratio 20:1, attack 1ms, release 50ms).
- **Material Design 3** con ViewBinding.
- **Filtro SearchView en tiempo real** para catálogo de MP3 en MediaStore.
- **Segundo plano**: Servicio en primer plano con `foregroundServiceType="mediaPlayback"`.

## Cómo abrir en Android Studio
1. Descomprime este archivo ZIP.
2. Abre Android Studio (Hedgehog, Iguana o posterior).
3. Selecciona **File -> Open...** y elige la carpeta descomprimida.
4. Espera a que Gradle sincronice las dependencias automáticas de Media3 1.2.1.
5. Ejecuta la app en un dispositivo o emulador con Android 9.0 (API 28) o superior.
