package com.ats.audioplayer;

import android.net.Uri;

public class Song {
    private final long id;
    private final String title;
    private final String artist;
    private final long duration;
    private final String path;
    private final Uri uri;
    private final long albumId;

    public Song(long id, String title, String artist, long duration, String path, Uri uri, long albumId) {
        this.id = id;
        this.title = title != null ? title : "Unknown Title";
        this.artist = artist != null ? artist : "Unknown Artist";
        this.duration = duration;
        this.path = path != null ? path : "";
        this.uri = uri;
        this.albumId = albumId;
    }

    public long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }

    public long getDuration() {
        return duration;
    }

    public String getPath() {
        return path;
    }

    public Uri getUri() {
        return uri;
    }

    public long getAlbumId() {
        return albumId;
    }

    public String getFormattedDuration() {
        long minutes = (duration / 1000) / 60;
        long seconds = (duration / 1000) % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }
}